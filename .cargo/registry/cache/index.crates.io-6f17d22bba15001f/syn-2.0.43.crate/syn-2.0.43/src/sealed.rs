#[cfg(feature = "parsing")]
pub(crate) mod lookahead {
    pub trait Sealed: Copy {}
}
