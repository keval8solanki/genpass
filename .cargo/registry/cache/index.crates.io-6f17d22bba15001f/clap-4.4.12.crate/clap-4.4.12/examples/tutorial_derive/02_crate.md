```console
$ 02_crate_derive --help
A simple to use, efficient, and full-featured Command Line Argument Parser

Usage: 02_crate_derive[EXE] --two <TWO> --one <ONE>

Options:
      --two <TWO>  
      --one <ONE>  
  -h, --help       Print help
  -V, --version    Print version

$ 02_crate_derive --version
clap [..]

```
